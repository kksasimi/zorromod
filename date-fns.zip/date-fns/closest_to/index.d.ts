declare module 'date-fns/closest_to' {
  import {closestTo} from 'date-fns'
  export = closestTo
}
