declare module 'date-fns/is_past' {
  import {isPast} from 'date-fns'
  export = isPast
}
