declare module 'date-fns/is_friday' {
  import {isFriday} from 'date-fns'
  export = isFriday
}
