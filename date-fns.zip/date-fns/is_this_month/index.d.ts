declare module 'date-fns/is_this_month' {
  import {isThisMonth} from 'date-fns'
  export = isThisMonth
}
