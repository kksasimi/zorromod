declare module 'date-fns/is_date' {
  import {isDate} from 'date-fns'
  export = isDate
}
