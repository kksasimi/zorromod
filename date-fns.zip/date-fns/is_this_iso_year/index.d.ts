declare module 'date-fns/is_this_iso_year' {
  import {isThisISOYear} from 'date-fns'
  export = isThisISOYear
}
