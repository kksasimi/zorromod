declare module 'date-fns/is_this_second' {
  import {isThisSecond} from 'date-fns'
  export = isThisSecond
}
