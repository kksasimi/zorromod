declare module 'date-fns/is_sunday' {
  import {isSunday} from 'date-fns'
  export = isSunday
}
