declare module 'date-fns/is_this_iso_week' {
  import {isThisISOWeek} from 'date-fns'
  export = isThisISOWeek
}
