declare module 'date-fns/locale/el' { }
