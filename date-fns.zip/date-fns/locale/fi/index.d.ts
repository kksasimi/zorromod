declare module 'date-fns/locale/fi' { }
