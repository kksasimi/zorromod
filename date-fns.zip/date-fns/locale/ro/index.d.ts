declare module 'date-fns/locale/ro' { }
