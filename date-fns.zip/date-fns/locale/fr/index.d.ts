declare module 'date-fns/locale/fr' { }
