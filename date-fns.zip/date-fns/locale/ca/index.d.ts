declare module 'date-fns/locale/ca' { }
