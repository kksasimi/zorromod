declare module 'date-fns/locale/da' { }
