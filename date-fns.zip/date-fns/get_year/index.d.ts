declare module 'date-fns/get_year' {
  import {getYear} from 'date-fns'
  export = getYear
}
