declare module 'date-fns/is_this_hour' {
  import {isThisHour} from 'date-fns'
  export = isThisHour
}
