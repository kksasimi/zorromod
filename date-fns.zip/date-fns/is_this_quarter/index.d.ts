declare module 'date-fns/is_this_quarter' {
  import {isThisQuarter} from 'date-fns'
  export = isThisQuarter
}
