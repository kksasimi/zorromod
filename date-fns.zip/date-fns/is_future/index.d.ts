declare module 'date-fns/is_future' {
  import {isFuture} from 'date-fns'
  export = isFuture
}
