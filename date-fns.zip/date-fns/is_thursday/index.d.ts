declare module 'date-fns/is_thursday' {
  import {isThursday} from 'date-fns'
  export = isThursday
}
