declare module 'date-fns/is_yesterday' {
  import {isYesterday} from 'date-fns'
  export = isYesterday
}
