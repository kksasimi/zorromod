declare module 'date-fns/add_months' {
  import {addMonths} from 'date-fns'
  export = addMonths
}
