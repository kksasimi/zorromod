declare module 'date-fns/add_hours' {
  import {addHours} from 'date-fns'
  export = addHours
}
