declare module 'date-fns/is_monday' {
  import {isMonday} from 'date-fns'
  export = isMonday
}
