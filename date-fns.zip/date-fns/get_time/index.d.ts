declare module 'date-fns/get_time' {
  import {getTime} from 'date-fns'
  export = getTime
}
