declare module 'date-fns/get_hours' {
  import {getHours} from 'date-fns'
  export = getHours
}
