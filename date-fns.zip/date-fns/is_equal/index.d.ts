declare module 'date-fns/is_equal' {
  import {isEqual} from 'date-fns'
  export = isEqual
}
